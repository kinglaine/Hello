package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView textView = ((TextView) findViewById(R.id.text));
        // Change text color button
        findViewById(R.id.color).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                // Change text color
                ((TextView) findViewById(R.id.text)).setTextColor(getResources().getColor(R.color.white));
            }
        });
        // change background color
        findViewById(R.id.changeBackgroundButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.parent).setBackgroundColor(getResources().getColor(R.color.light_green));
            }
        });
        // change text
        findViewById(R.id.changeTextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TextView)findViewById(R.id.text)).setText("Android is Awesome!");
            }
        });
        // Tap on background to reset all views to default setting
        findViewById(R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // reset text
                ((TextView)findViewById(R.id.text)).setText("Hello from Caren!");
                // reset text color
                textView.setTextColor( getResources().getColor(R.color.black));
                // reset background color
                findViewById(R.id.parent).setBackgroundColor(getResources().getColor(R.color.light_blue));

            }
        });
        // change user text to text view
        findViewById(R.id.Customtext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usertext = ((EditText) findViewById(R.id.editText)).getText().toString();
                // if edit text empty add a default string
                if (usertext.isEmpty()){
                    textView.setText("Enter your own text!");
                }
                else{
                textView.setText(usertext);
            }}
        });

    }
}